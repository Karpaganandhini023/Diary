# Diary App

This application is built using Django and QuillJS.

Features:

1. Create note.
2. View Bunch of notes.
3. View individual notes.

## Snapshots

![Productivity Chart](https://i.ibb.co/vvM5ggN/Screenshot-from-2019-10-20-00-29-35.png)
![Nothing to Show](https://i.ibb.co/Vv1RYb2/Screenshot-from-2019-10-20-00-30-12.png)
![Add Note](https://i.ibb.co/WWdrn16/Screenshot-from-2019-10-19-19-48-38.png)
![View Bunch of Notes](https://i.ibb.co/F6P7CyQ/Screenshot-from-2019-10-19-19-48-49.png)
![View Individual Notes](https://i.ibb.co/Cv6tpXW/Screenshot-from-2019-10-19-19-49-06.png)